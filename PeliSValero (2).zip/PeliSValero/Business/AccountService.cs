
using PeliSValero.Data;
using PeliSValero.Models;

namespace PeliSValero.Business
{
    public class AccountService
    {
        private readonly IPeliSValeroRepository _repository;

        public AccountService(IPeliSValeroRepository repository)
        {
            _repository = repository;
        }

        public void CreateAccount(string username, string phoneNumber, decimal capital)
        {
            var newAccount = new Account
            {
                Username = username,
                PhoneNumber = phoneNumber,
                Capital = capital
            };

            _repository.AddAccount(newAccount);
        }

        public void UpdateAccount(string username, string newPhoneNumber, decimal newCapital)
        {
            var updatedAccount = new Account
            {
                Username = username,
                PhoneNumber = newPhoneNumber,
                Capital = newCapital
            };

            _repository.UpdateAccount(updatedAccount);
        }
    }
}
