
using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json;
using PeliSValero.Models;

namespace PeliSValero.Data
{
    public class PeliSValeroRepository : IPeliSValeroRepository
    {
        private const string JsonFilePath = "accounts.json";

        public List<Account> GetAllAccounts()
        {
            if (!File.Exists(JsonFilePath))
            {
                return new List<Account>();
            }

            var json = File.ReadAllText(JsonFilePath);
            return JsonConvert.DeserializeObject<List<Account>>(json);
        }

        public void AddAccount(Account account)
        {
            var accounts = GetAllAccounts();
            accounts.Add(account);
            SaveAccounts(accounts);
        }

        public void UpdateAccount(Account account)
        {
            var accounts = GetAllAccounts();
            var existingAccount = accounts.Find(a => a.Username == account.Username);

            if (existingAccount != null)
            {
                existingAccount.PhoneNumber = account.PhoneNumber;
                existingAccount.Capital = account.Capital;
                SaveAccounts(accounts);
            }
        }

        private void SaveAccounts(List<Account> accounts)
        {
            var json = JsonConvert.SerializeObject(accounts, Formatting.Indented);
            File.WriteAllText(JsonFilePath, json);
        }
    }
}