
using System;
using PeliSValero.Business;
using PeliSValero.Data;

namespace PeliSValero.Presentation
{
    class Menu
    {
        static void Main(string[] args)
        {
            var repository = new PeliSValeroRepository();
            var accountService = new AccountService(repository);
            Console.WriteLine("ELIJA UNA DE LAS OPCIONES");
            Console.WriteLine("1. Crear cuenta");
            Console.WriteLine("2. Actualizar cuenta");
            Console.Write("Seleccione una opción: ");

            if (int.TryParse(Console.ReadLine(), out int option))
            {
                switch (option)
                {
                    case 1:
                        Console.Write("Ingrese el nombre de usuario: ");
                        string username = Console.ReadLine();

                        Console.Write("Ingrese el número de teléfono: ");
                        string phoneNumber = Console.ReadLine();

                        Console.Write("Ingrese el capital del usuario: ");
                        if (decimal.TryParse(Console.ReadLine(), out decimal capital))
                        {
                            accountService.CreateAccount(username, phoneNumber, capital);
                            Console.WriteLine("Cuenta creada con éxito.");
                        }
                        else
                        {
                            Console.WriteLine("Entrada no válida para el capital. Se esperaba un valor numérico.");
                        }
                        break;

                    case 2:
                        Console.Write("Ingrese el nombre de usuario para actualizar: ");
                        string usernameToUpdate = Console.ReadLine();

                        Console.Write("Ingrese el nuevo número de teléfono: ");
                        string newPhoneNumber = Console.ReadLine();

                        Console.Write("Ingrese el nuevo capital del usuario: ");
                        if (decimal.TryParse(Console.ReadLine(), out decimal newCapital))
                        {
                            accountService.UpdateAccount(usernameToUpdate, newPhoneNumber, newCapital);
                            Console.WriteLine("Cuenta actualizada con éxito.");
                        }
                        else
                        {
                            Console.WriteLine("Entrada no válida para el nuevo capital. Se esperaba un valor numérico.");
                        }
                        break;

                    default:
                        Console.WriteLine("Opción no válida.");
                        break;
                }
            }
            else
            {
                Console.WriteLine("Entrada no válida. Se esperaba un número.");
            }
        }
    }
}