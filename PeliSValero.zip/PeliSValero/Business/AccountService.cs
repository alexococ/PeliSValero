using Newtonsoft.Json;
using PeliSValero.Data;
using PeliSValero.Models;
using System;
using System.ComponentModel.Design;
using System.Text.Json;



namespace PeliSValero.Business
{
    public class AccountService
    {


        /* -------------- METODOS PARA LA ZONA PÚBLICA (TODOS LOS USUARIOS) -----------*/

        // crear cuenta
        public static Account CrearCuenta()
        {
            Console.WriteLine("Ingrese el Username:");
            string username = Console.ReadLine();

            Console.WriteLine("Ingresa tu Nombre");
            string firstName = Console.ReadLine();

            Console.WriteLine("Ingresa tu apellido");
            string lastName = Console.ReadLine();

            Console.WriteLine("Ingresa tu DNI");
            string nif = Console.ReadLine();

            Console.WriteLine("Ingresa un capital inicial");


            Account account = new Account();

            if (decimal.TryParse(Console.ReadLine(), out decimal balance))
            {
                account = new Account()
                {
                    Username = username,
                    FirstName = firstName,
                    LastName = lastName,
                    NIF = nif,
                    Balance = balance
                };

                Console.WriteLine("Cuenta creada con éxito.");
            }
            else
            {
                Console.WriteLine("Entrada inválida para el capital. Inténtalo de nuevo.");
            }

            return account;
        }



        // mostrar detalles al crear cuenta
        public static void ShowDetails(List<Account> usuariosCreados)
        {
            for (int i = 0; i < usuariosCreados.Count; i++)
            {
                Console.WriteLine($"{i}: Bienvenido: {usuariosCreados[i].Username} Con los datos: Nombre: {usuariosCreados[i].FirstName} Apellido: {usuariosCreados[i].LastName}  DNI: {usuariosCreados[i].NIF} y con un balance de: {usuariosCreados[i].Balance}");
            }
        }



        // ingresar datos en DataUsers.json
        public static void UserData(List<Account> usuariosCreados)
        {
            string Nombre = @"D:\PeliSValero\Data\DataUsers.json";
            var option = new JsonSerializerOptions { WriteIndented = true };

            string jsonString = System.Text.Json.JsonSerializer.Serialize(usuariosCreados, option);
            File.WriteAllText(Nombre, jsonString);
        }



        // entrar en una cuenta
        public static bool isCuentaValida(List<Account> usuariosCreados, Account cuentaExistente)
        {

            foreach (Account usuario in usuariosCreados)
            {
                if (usuario.NIF.Equals(cuentaExistente.NIF))
                {
                    return true;
                }
            }
            Console.WriteLine("¡Contraseña incorrecta!");
            return false;
        }

        public static Account UsuarioExistente(List<Account> usuariosCreados)
        {
            Console.WriteLine("Ingresa DNI (contraseña):");
            string dniIngresado = Console.ReadLine();

            foreach (Account cuenta in usuariosCreados)
            {
                if (cuenta.NIF == dniIngresado)
                {
                    Console.WriteLine("¡DNI (contraseña) correcto!");
                    return new Account
                    {
                        FirstName = cuenta.FirstName,
                        LastName = cuenta.LastName,
                        NIF = cuenta.NIF,
                        Username = cuenta.Username,
                        Balance = cuenta.Balance,
                    };
                }
            }

            Console.WriteLine("¡DNI (contraseña) incorrecto!");
            return null; // Retorna null si no se encuentra la cuenta
        }


        public static void MostrarPeliculas()
        {
            string filePath = @"D:\PeliSValero\Data\DataMovies.json";


            // Verificar si el archivo existe
            if (File.Exists(filePath))
            {
                // Leer el contenido del archivo
                string jsonString = File.ReadAllText(filePath);

                // Deserializar el JSON a una lista de objetos Ejemplo
                List<Movie> ejemplos = JsonConvert.DeserializeObject<List<Movie>>(jsonString);

                // Recorrer la lista e imprimir los valores
                foreach (var ejemplo in ejemplos)
                {
                    Console.WriteLine($"Nombre: {ejemplo.Title}, Precio: {ejemplo.Price}");
                }
            }
            else
            {
                Console.WriteLine("El archivo no existe.");
            }
        }







        /* METODOS PARA LA ZONA PRIVADA (DENTRO DE UNA CUENTA DE USUARIO) */
        private void ModificarDatosCuenta()
        {

        }

        private void ComprarPeliculas()
        {

        }


        private void VerHistorialDeCompras()
        {

        }




    }
}
