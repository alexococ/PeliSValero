using Newtonsoft.Json;
using PeliSValero.Data;
using PeliSValero.Models;
using System;
using System.ComponentModel.Design;
using System.Text.Json;



namespace PeliSValero.Business
{

    public class MovieService
    {


        // metodo para mostrar toda la lista de películas
        public static void MostrarPeliculas()
        {
            string filePath = @"../Data/DataMovies.json";


            // Verificar si el archivo existe
            if (File.Exists(filePath))
            {
                // Leer el contenido del archivo
                string jsonString = File.ReadAllText(filePath);

                // Deserializar el JSON a una lista de objetos Ejemplo
                List<Movie> ejemplos = JsonConvert.DeserializeObject<List<Movie>>(jsonString);

                // Recorrer la lista e imprimir los valores
                foreach (var ejemplo in ejemplos)
                {
                    Console.WriteLine($"Nombre: {ejemplo.Title}, Precio: {ejemplo.Price}");
                }
            }
            else
            {
                Console.WriteLine("El archivo no existe.");
            }
        }


        // ruta del archivo de películas(DataMovies.json)
        private const string MoviesFilePath = "../Data/DataMovies.json";

        
        // metodo para comprar las peliculas
        public static void ComprarPeliculas(Account cuentaExistente, List<Account> usuariosCreados)
        {
            Console.WriteLine("Ingrese el nombre de una película existente:");
            string nombrePelicula = Console.ReadLine();

            // Obtener la lista de películas desde el archivo JSON
            List<Movie> listaPeliculas = ObtenerPeliculasDesdeArchivo();

            // Buscar la película por nombre
            Movie peliculaSeleccionada = BuscarPeliculaPorNombre(nombrePelicula, listaPeliculas);

            if (peliculaSeleccionada != null && peliculaSeleccionada.InStock)
            {
                Console.WriteLine($"¿Estás seguro que quieres comprar la película '{peliculaSeleccionada.Title}'? (Si/No)");
                string respuesta = Console.ReadLine();

                if (respuesta.Equals("Si", StringComparison.OrdinalIgnoreCase))
                {
                    // Comprar la película
                    if (cuentaExistente.Balance >= peliculaSeleccionada.Price)
                    {
                        cuentaExistente.Balance -= peliculaSeleccionada.Price;
                        Console.WriteLine($"Has comprado la película '{peliculaSeleccionada.Title}'.");
                        AccountService.UserData(usuariosCreados);
                    }
                    else
                    {
                        Console.WriteLine("Saldo insuficiente para comprar la película.");
                    }
                }
                else if (respuesta.Equals("No", StringComparison.OrdinalIgnoreCase))
                {
                    Console.WriteLine("Has decidido no comprar la película.");
                }
                else
                {
                    Console.WriteLine("Solo puedes introducir Si o No. Volviendo al menú.");
                }
            }
            else
            {
                Console.WriteLine("La película no existe o no está disponible en stock. Volviendo al menú.");
            }


        }


        // metodo para obtener las películas
        private static List<Movie> ObtenerPeliculasDesdeArchivo()
        {
            try
            {
                string json = File.ReadAllText(MoviesFilePath);
                return JsonConvert.DeserializeObject<List<Movie>>(json) ?? new List<Movie>();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error al leer el archivo de películas: {ex.Message}");
                return new List<Movie>();
            }
        }


        // metodo para buscar las peliculas por el nombre
        private static Movie BuscarPeliculaPorNombre(string nombre, List<Movie> listaPeliculas)
        {
            return listaPeliculas.Find(pelicula => pelicula.Title.Equals(nombre, StringComparison.OrdinalIgnoreCase));
        }






        // metodo para ver el historial de las compras
        public static void VerHistorialDeCompras(Account cuentaExistente)
        {
            
        }



    }










}