using System.Collections.Generic;
using PeliSValero.Models;

namespace PeliSValero.Data
{
    public interface IPeliSValeroRepository
    {
        List<Account> GetAllAccounts();
        void AddAccount(Account account);
        void UpdateAccount(Account account);
    }
}