namespace PeliSValero.Data{
    // METODOS PARA CARGAR O GUARDAR PELICULAS "MOVIES" EN UN ARCHIVO JSON (DataMovies)
    public class MoviesRepository{
        
    }
}
