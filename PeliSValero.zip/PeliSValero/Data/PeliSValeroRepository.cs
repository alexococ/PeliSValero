using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json;
using PeliSValero.Models;

namespace PeliSValero.Data
{
    public class PeliSValeroRepository
    {

    }
}
