namespace PeliSValero.Models
{
    public class Account
    {
        public string? Username { get; set; }
        public string? PhoneNumber { get; set; }
        public decimal Capital { get; set; }
    }
}