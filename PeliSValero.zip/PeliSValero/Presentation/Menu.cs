
using System;
using PeliSValero.Business;
using PeliSValero.Data;

using System;
using System.Reflection.Metadata;
using PeliSValero.Models;

namespace PeliSValero.Presentation
{
    class Menu
    {

        /* ZONA DE MENU PUBLICO A TODOS LOS USUARIOS */
        public void MostrarMenuPrincipal()
        {
            List<Account> usuariosCreados = new List<Account>();
            while (true)
            {

                Console.WriteLine("=======================================");
                Console.WriteLine("==     BIENVENIDO A PeliSValero      ==");
                Console.WriteLine("==  SELECCIONE UNA DE LAS OPCIONES ==  ");
                Console.WriteLine("=======================================");

                Console.WriteLine("1. Crear una cuenta");
                Console.WriteLine("2. Entrar a una cuenta");
                Console.WriteLine("3. Ver todas las películas");
                Console.WriteLine("4. Salir del programa");

                Console.WriteLine("=======================================");

                int? opcion;
                if (int.TryParse(Console.ReadLine(), out int resultado))
                {
                    opcion = resultado;
                }
                else
                {
                    Console.WriteLine("Entrada no válida, por favor, ingrese un número");
                    continue;

                }

                switch (opcion)
                {
                    case 1:

                        Account usuarioNuevo = AccountService.CrearCuenta();
                        usuariosCreados.Add(usuarioNuevo);

                        AccountService.ShowDetails(usuariosCreados);
                        AccountService.UserData(usuariosCreados);

                        break;

                    case 2:
                        Account cuentaExistente = AccountService.UsuarioExistente(usuariosCreados);

                        bool isCuentaExistente = AccountService.isCuentaValida(usuariosCreados, cuentaExistente);
                        if (isCuentaExistente)
                        {
                            MostrarMenuCuenta();
                        }
                        break;

                    case 3:
                        AccountService.MostrarPeliculas();
                        break;

                    case 4:
                        Environment.Exit(0);
                        break;

                    default:
                        Console.WriteLine("Opción no válida. Inténtelo de nuevo");
                        break;
                }

            }
        }





        /* ZONA DE MENU PRIVADO DENTRO DE LA CUENTA */
        public void MostrarMenuCuenta()
        {

            Console.WriteLine("=======================================");
            Console.WriteLine("==  BIENVENIDO A AJUSTES DE CUENTA   ==");
            Console.WriteLine("==  SELECCIONE UNA DE LAS OPCIONES ==  ");
            Console.WriteLine("=======================================");

            Console.WriteLine("1. Cambiar datos de la cuenta");
            Console.WriteLine("2. Alquilar una película");
            Console.WriteLine("3. Ver todas las películas");
            Console.WriteLine("4. Salir del programa");

            Console.WriteLine("=======================================");

            string opcion = Console.ReadLine();

            switch (opcion)
            {
                case "1":
                    // METODO PARA CAMBIAR LOS DATOS DE UNA CUENTA
                    break;
                case "2":
                    // METODO PARA ALQUILAR UNA PELÍCULA
                    break;
                case "3":
                    AccountService.MostrarPeliculas();
                    break;
                case "4":
                    // METODO PARA SALIR DEL PROGRAMA
                    Environment.Exit(0);
                    break;
                default:
                    Console.WriteLine("Opción no válida. Inténtelo de nuevo");
                    break;
            }
        }

    }

}