﻿using PeliSValero.Business;
using PeliSValero.Data;
using PeliSValero.Presentation;

class Program
{
    static void Main()
    {
        var menu = new PeliSValero.Presentation.Menu();
        menu.MostrarMenuPrincipal();
    }
}